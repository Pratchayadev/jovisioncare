import { defineConfig } from "drizzle-kit";

try { process.loadEnvFile(".env"); } catch {}

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dialect: process.env.DATABASE_AUTH_TOKEN ? "turso" : "sqlite",
  dbCredentials: {
    url: process.env.DATABASE_URL || "file:./data/jovisioncare.db",
    authToken: process.env.DATABASE_AUTH_TOKEN,
  } as { url: string },
});
