# J.O. Vision Care — เว็บไซต์ร้านแว่น + ระบบหลังบ้าน

สร้างจากดีไซน์ `JO Vision Care.dc.html` (Claude Design) เน้น SEO และรองรับมือถือเป็นหลัก

## Tech stack

| ส่วน | ใช้ |
|---|---|
| Framework | **Next.js 15 (App Router) + TypeScript** — Server Components, ISR |
| ฐานข้อมูล | **SQLite ผ่าน libsql + Drizzle ORM** — ไฟล์เดียวที่ `data/jovisioncare.db` ย้ายไป Turso ได้โดยแก้ `.env` อย่างเดียว |
| รูปภาพ | `next/image` (AVIF/WebP อัตโนมัติ) · อัปโหลดถูกย่อและแปลงเป็น WebP ด้วย `sharp` · เก็บที่ `data/uploads` หรือ **Cloudflare R2** |
| หลังบ้าน | `/admin` — Server Actions, เซสชัน cookie แบบเซ็น HMAC, รหัสผ่านแบบ scrypt |
| สไตล์ | CSS ธรรมดา (แปลงจากดีไซน์) + ฟอนต์ IBM Plex Sans Thai / Bebas Neue / IBM Plex Mono แบบ self-host |

## เริ่มใช้งาน

ต้องมี Node.js 20 ขึ้นไป

```bash
npm install
cp .env.example .env
npm run hash-password -- "รหัสผ่านของคุณ"   # นำบรรทัดที่ได้ไปใส่ใน .env
openssl rand -hex 32                        # นำค่าที่ได้ไปใส่ SESSION_SECRET ใน .env
npm run setup                               # สร้างตาราง + ใส่ข้อมูลตั้งต้นจากดีไซน์
npm run dev                                 # http://localhost:3000
```

หลังบ้าน: http://localhost:3000/admin

## ระบบหลังบ้าน

- **สินค้า**: เพิ่ม ลบ แก้ไข ค้นหา และกรองตามหมวดหมู่หรือแบรนด์ · อัปโหลดได้หลายรูปพร้อมกัน แก้ alt และลำดับรูป หรือลบรูปได้ · กดสลับเผยแพร่/ซ่อนได้ในคลิกเดียว · เลือกได้ว่าจะแสดงในคอลเลกชันหน้าแรกหรือไม่
- **หมวดหมู่ / แบรนด์**: เพิ่ม ลบ แก้ไข พร้อมคำอธิบายและลำดับ · แบรนด์อัปโหลดโลโก้ได้ · เมื่อลบหมวดหมู่หรือแบรนด์ สินค้าข้างในจะไม่ถูกลบ
- **SEO ทุกหน้า**: ตั้ง Slug, Meta title และ Meta description ได้ พร้อมพรีวิวหน้าตาบน Google
- เมื่อบันทึก หน้าเว็บและ sitemap จะอัปเดตทันที
- ปุ่มลบเป็นแบบกดสองครั้งเพื่อยืนยัน ใช้บนมือถือได้สะดวก

## SEO ที่ทำไว้แล้ว

- HTML ถูก render ฝั่ง server ทั้งหมด ทำให้ Google อ่านเนื้อหาได้ครบโดยไม่ต้องรัน JS · ใช้ ISR (cache 1 ชั่วโมง และล้าง cache ทันทีเมื่อแก้ข้อมูลในหลังบ้าน)
- มีหน้าแยกที่ index ได้: `/products/[slug]`, `/category/[slug]`, `/brand/[slug]`, `/products` · การ์ดสินค้าเป็นลิงก์จริง โดยหน้าแรกจะเปิดเป็นป๊อปอัปตามดีไซน์
- JSON-LD: `Optician` ×2 สาขา, `WebSite`, `Product` (+`Offer` เมื่อใส่ราคา), `BreadcrumbList`, `CollectionPage`/`ItemList`
- `sitemap.xml` (รวม image sitemap), `robots.txt` (กัน `/admin`), canonical, Open Graph, Twitter card, `lang="th"`, manifest
- Core Web Vitals: preload ฟอนต์ไทย, รูป hero เป็น priority, รูปอื่น lazy-load พร้อม `srcset` และ `sizes` ที่เหมาะกับมือถือ

## สิ่งที่ต้องแก้ก่อนเปิดใช้จริง

1. `src/lib/site.ts` — ใส่ **ที่อยู่ เวลาเปิด-ปิด และเบอร์โทร** ทั้ง 2 สาขา (ตอนนี้ยังเป็น `[ใส่ที่อยู่…]` ตามดีไซน์) และควรใส่ `telephone`, `geo`, `openingHours` ใน JSON-LD ด้วยเพื่อช่วย Local SEO
2. `.env` — ตั้ง `SITE_URL` เป็นโดเมนจริง (ใช้ทำ canonical และ sitemap)
3. รูปบรรยากาศร้าน 4 ช่อง และรูปรีวิว IG ยังเป็น placeholder ตามดีไซน์
4. ลงทะเบียน Google Search Console แล้วส่ง `https://โดเมน/sitemap.xml` · สร้าง Google Business Profile ทั้ง 2 สาขา

## Deploy

**VPS (แนะนำ เพราะ SQLite และรูปอยู่บนดิสก์):**

```bash
npm ci && npm run setup && npm run build
pm2 start npm --name jovisioncare -- start   # พอร์ต 3000 แล้วตั้ง Nginx หรือ Cloudflare ไว้ด้านหน้า
```

สำรองข้อมูลด้วยการ copy โฟลเดอร์ `data/` (มีทั้งฐานข้อมูลและรูปที่อัปโหลด)

**Vercel / serverless:** ดิสก์ไม่ถาวร จึงต้องใช้ฐานข้อมูล **Turso** (`DATABASE_URL=libsql://…` + `DATABASE_AUTH_TOKEN`) และเก็บรูปบน **R2** (`R2_*` ใน `.env`)

## โครงสร้าง

```
src/
  app/(site)/        หน้าเว็บสาธารณะ (หน้าแรก, สินค้า, หมวดหมู่, แบรนด์)
  app/admin/         หลังบ้าน + server actions
  app/uploads/       เสิร์ฟรูปที่อัปโหลด
  app/sitemap.ts, robots.ts, manifest.ts
  components/        ส่วนประกอบหน้าเว็บ (Hero, LensLab, Collection, Gallery…)
  components/admin/  ฟอร์มหลังบ้าน
  db/schema.ts       โครงสร้างตาราง · db/seed.ts ข้อมูลตั้งต้น
  lib/               db, queries, auth, storage (local/R2), site config
```

คำสั่งอื่น: `npm run db:studio` (เปิดดู/แก้ฐานข้อมูลผ่านเว็บ), `npm run db:push` (อัปเดตตารางหลังแก้ schema)
