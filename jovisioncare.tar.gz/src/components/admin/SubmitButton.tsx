"use client";
import { useFormStatus } from "react-dom";
export default function SubmitButton({ children = "บันทึก" }: { children?: React.ReactNode }) {
  const { pending } = useFormStatus();
  return <button type="submit" className="btn-a primary" disabled={pending}>{pending ? "กำลังบันทึก…" : children}</button>;
}
