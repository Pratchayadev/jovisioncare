import { drizzle } from "drizzle-orm/libsql";
import { createClient, type Client } from "@libsql/client";
import * as schema from "@/db/schema";

const g = globalThis as unknown as { libsql?: Client };
const client =
  g.libsql ??
  createClient({ url: process.env.DATABASE_URL || "file:./data/jovisioncare.db", authToken: process.env.DATABASE_AUTH_TOKEN || undefined });
if (process.env.NODE_ENV !== "production") g.libsql = client;

export const db = drizzle(client, { schema });
export * as t from "@/db/schema";
